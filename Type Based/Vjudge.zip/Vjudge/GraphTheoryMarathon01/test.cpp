#include <iostream>
#include <unordered_set>
#include <vector>

int countCommonElements(const std::vector<int>& vec1, const std::vector<int>& vec2) {
    std::unordered_set<int> elementsSet(vec1.begin(), vec1.end());

    int commonCount = 0;
    for (const int& element : vec2) {
        if (elementsSet.find(element) != elementsSet.end()) {
            ++commonCount;
        }
    }

    return commonCount;
}

int main() {
    std::vector<int> vec1 = {1, 2, 3, 4, 5};
    std::vector<int> vec2 = {3, 4, 5, 6, 7};

    int commonCount = countCommonElements(vec1, vec2);

    std::cout << "Number of common elements: " << commonCount << std::endl;

    return 0;
}
