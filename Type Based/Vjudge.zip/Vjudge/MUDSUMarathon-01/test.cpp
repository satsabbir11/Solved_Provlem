#include <bits/stdc++.h>
using namespace std;
#define endl "\n"
#define con (f ? "YES" : "NO")
#define loj(i, j) "Case " << i << ": " << j

int minNumberOfCoinsNeedToGetAValue(vector<int>&coins, int targetValue, int n, vector<int>&dp){
    if(targetValue==0) return 0;
    if(dp[targetValue]!=-1) return dp[targetValue];

    int ans = INT_MAX; //firstly answer is maximum

    for(int i=0;i<n;i++){
        if(coins[i]<=targetValue){
            int subAns = minNumberOfCoinsNeedToGetAValue(coins, targetValue-coins[i], n, dp); //iterate over all coins
            if(subAns!=INT_MAX && subAns+1<ans) ans = subAns+1; //if subsans is minimum put it
        }
    }

   
    return dp[targetValue] = ans;
}

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0), cout.tie(0);

    int n, val;
    cin >> n;

    vector<int>v(n);
   
    for (long long i = 0; i < n; i++) cin>>v[i];

    cin>>val;
    vector<int>dp(val+5, -1);

    cout<<minNumberOfCoinsNeedToGetAValue(v, val, n, dp)<<endl;
    
}