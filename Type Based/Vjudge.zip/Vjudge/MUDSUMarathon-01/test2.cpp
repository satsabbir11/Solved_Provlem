#include<bits/stdc++.h>
using namespace std;
#define endl "\n"
#define con (f?"YES":"NO")
#define loj(i,j) "Case "<<i<<": "<<j

int numberOfAllPossibleWays(vector<int>& coins, int i, int targetValue, vector<vector<int>>& dp) {
    if (targetValue == 0) return 1;
    if (targetValue < 0 || i <= 0) return 0;
    if (dp[i][targetValue] != -1) return dp[i][targetValue];
    return dp[i][targetValue] = numberOfAllPossibleWays(coins, i - 1, targetValue, dp) + numberOfAllPossibleWays(coins, i, targetValue - coins[i - 1], dp);
}

int main() {
    ios_base::sync_with_stdio(false); cin.tie(0), cout.tie(0);

    int n, val;
    cin >> n >> val;
    vector<int> coins(n);
    for(int& x : coins) cin >> x;

    vector<vector<int>>dp(n+5, vector<int>(val+5, -1));

    cout << numberOfAllPossibleWays(coins, n, val, dp) << endl;
}
